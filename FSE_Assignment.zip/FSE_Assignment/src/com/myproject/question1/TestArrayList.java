package com.myproject.question1;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;
public class TestArrayList {

	public static void main(String[] args) {
		//Creating new instance of ArrayList
		ArrayList<Integer> listOfNumbers=new ArrayList<>();
		//Pushing elements in ArrayList
		pushElements(listOfNumbers);
		//Traversing ArrayList using while loop
		traverseListUsingWhile(listOfNumbers);
		//Traversing ArrayList using enhanced for loop
		traverseListUsingEnhancedFor(listOfNumbers);
		//Traversing ArrayList using for loop
		traverseListUsingFor(listOfNumbers);

	}
	static void pushElements(ArrayList<Integer> listOfNumbers)
	{
		int i=0;
		int numberOfElements=0;
		int data=0;
		//Creating an instance of Scanner to get input from user
		Scanner sc=new Scanner(System.in);
		//Accepting the no.of elements to store in arraylist
		System.out.println("Enter the number of elements to push");
		numberOfElements=sc.nextInt();
		
		//for loop to accept the elements from user and store in arraylist
		for(i=0;i<numberOfElements;i++)
		{
			System.out.println("Enter the element to store");
			data=sc.nextInt();
			listOfNumbers.add(data);
		}
		
	}
	static void traverseListUsingWhile(ArrayList<Integer> listOfNumbers)
	{
		System.out.println("While Loop:");
		Iterator<Integer> iterator=listOfNumbers.iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
		
	}
	static void traverseListUsingEnhancedFor(ArrayList<Integer> listOfNumbers)
	{

		System.out.println("Advanced For Loop:");
		for(Integer number:listOfNumbers)
		{
			System.out.println(number);
		}
		
	}
	static void traverseListUsingFor(ArrayList<Integer>listOfNumbers)
	{
		System.out.println("For Loop:");
		for(int i=0;i<listOfNumbers.size();i++)	
		{
			System.out.println(listOfNumbers.get(i));
		}
	}

}
